for rodada in range(2,10,2):
    print(rodada)